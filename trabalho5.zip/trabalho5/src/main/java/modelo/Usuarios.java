package modelo;

import javax.persistence.Table;
@Table(name = "USUARIOS")
public class Usuarios {
}
